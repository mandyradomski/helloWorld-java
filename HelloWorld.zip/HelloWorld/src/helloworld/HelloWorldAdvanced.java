/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworld;

/**
 *
 * @author Malinka
 */
public class HelloWorldAdvanced {
    
    	public static void main(String[] args) 
	{
		int i = 0;
		while(i < 1000)
		{
			System.out.println("Hello World!");
			i = i +1;
		}
	}
    
}
